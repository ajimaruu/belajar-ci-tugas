<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
ini halaman produk<br>
<?= $this->endSection() ?>
